import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  constructor( private route:Router) { }
  ngOnInit() {
    alert('Logout Successfully');
    localStorage.removeItem("Username");
    localStorage.removeItem("UserDetails");
    localStorage.removeItem("Token");
    this.route.navigate(["Home"])
  }
}
