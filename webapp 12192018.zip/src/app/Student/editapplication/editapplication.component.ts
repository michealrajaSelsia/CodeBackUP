import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormControlName } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MaterialAppModule } from '../../MainConfig/ngmaterial.module';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
import { UserService } from '../../Services/public-api.service';
import { AdminLoginM } from '../../Models/Public/AdminLoginModel';
import { Response } from '@angular/http';
import {ApplicationModel} from '../../Models/Public/Application';

@Component({
  selector: 'app-editapplication',
  templateUrl: './editapplication.component.html',
  styleUrls: ['./editapplication.component.css']
})
export class EditapplicationComponent implements OnInit {

  filedata:any;   
  objApplicationModel:ApplicationModel
  errorMsg:string;
  ApplicationForm = new FormGroup({
    ApplicationID: new FormControl(''),
    Course: new FormControl(''),
    Fname: new FormControl(''),
    Lname: new FormControl(''),
    Fullname: new FormControl(''),
    DOB: new FormControl(''),
    Gender: new FormControl(''),
    FatherName: new FormControl(''),
    MotherName: new FormControl(''),
    Religion: new FormControl(''),
    Nationality: new FormControl(''),
    Email: new FormControl(''),
    MobileNo: new FormControl(''),
    P_Address: new FormControl(''),
    C_Address: new FormControl(''),
   // Photo: new FormControl(''),
    SSLCSchoolName: new FormControl(''),
    SSLCMark: new FormControl(''),
    SSLCPercentage: new FormControl(''),
    HSCSchoolName: new FormControl(''),
    HSCMark: new FormControl(''),
    HSCPercentage: new FormControl(''),
    UGSchoolName: new FormControl(''),
    UGMark: new FormControl(''),
    UGPercentage: new FormControl(''),
    PGSchoolName: new FormControl(''),
    PGMark: new FormControl(''),
    PGPercentage: new FormControl(''),
    CreateOn: new FormControl(''),
    isActive: new FormControl(''),
  });
  constructor(private http: Http, private route: Router, private myApiService:UserService) { }

  ngOnInit() {

  }
  uploadPhoto(e){
    this.filedata=e.target.files[0];
    console.log(e);
  }

  ClearFeild()
  {
    alert("Cleared");
  }

  onApplicationSubmit() {
    let formdata = new FormData();
    formdata.append("Name", "AAAAAAAAAAAAA");
    formdata.append("ProfilePhoto", this.filedata);
    console.log(this.filedata)

    this.objApplicationModel= Object.assign({},this.ApplicationForm.value);
    console.warn("Result"+this.objApplicationModel);
    
    this.myApiService.saveApplication(this.objApplicationModel).subscribe(
      data => {
        if(data)
         {
          alert("Success");
         }
         else
         {
          alert("Failed");
         }
      },
      error => {
        console.log("Error", error);
      }
    )
  }

}
