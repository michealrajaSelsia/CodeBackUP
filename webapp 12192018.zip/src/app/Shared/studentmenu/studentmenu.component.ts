import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentmenu',
  templateUrl: './studentmenu.component.html',
  styleUrls: ['./studentmenu.component.css']
})
export class StudentmenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
