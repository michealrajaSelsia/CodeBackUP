export class AdminLoginM {
    Username:string;
    Password:string;
}