export interface GalleryImage { 
   Id:number;
   Name :string;
   ImgPath :string;
   Description :string;
   Liked :string;
   DisLiked :string;   
}