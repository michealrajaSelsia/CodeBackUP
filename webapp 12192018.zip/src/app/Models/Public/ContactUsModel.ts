export class ContactUS
{
    Name:string;
    Email:string;
    Subject:string;
    Message:string;
}