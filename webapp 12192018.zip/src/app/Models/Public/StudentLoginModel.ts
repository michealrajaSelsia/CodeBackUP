export class StudentLoginM {
    Username:string;
    Password:string;
}