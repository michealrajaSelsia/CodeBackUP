
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GalleryImage } from '../Models/Public/GalleryImageModel';
import { HttpClientModule } from '@angular/common/http';
import { Http } from '@angular/http';
import { Response } from '@angular/http'
import { User } from '../Models/Public/UserModel';
import {ContactUS} from '../Models/Public/ContactUsModel';
import { AdminLoginM} from '../Models/Public/AdminLoginModel';
import { StudentLoginM} from '../Models/Public/StudentLoginModel';
import {  ApplicationModel  } from '../Models/Public/Application';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private serviceUrl = 'http://localhost:49728/api/Common/';


  constructor(private http: Http, private https: HttpClient) { }

  //Get Gallery Data
  getGalleryImages() {
    return this.http.get(this.serviceUrl+'GetGalleryImages');
  }

  getGalleryImages1(): Observable<GalleryImage[]> {
    return this.https.get<GalleryImage[]>(this.serviceUrl+'GetGalleryImages');
  }

  
  //Save user registration data
  public saveUserRegistrationData(data: User) {
    return this.https.post(this.serviceUrl+"SaveUser",
      {
        "Userid": "",
        "Name": data.Name,
        "Username": data.Username,
        "Password": data.Password,
        "EmailID": data.EmailID,
        "PhoneNo ": data.PhoneNo,
        "isActive": true
      });
  }

  //Save ContactUs data
  public  saveContactUsData(data: ContactUS) {
    return this.https.post(this.serviceUrl+"SaveContactUs",
      {
        "Name": data.Name,
        "Email": data.Email,        
        "Subject": data.Subject,
        "Message": data.Message,
      });
  }

//Validate Admin data
  public  validateAdmin(data:AdminLoginM ) {
    return this.https.post(this.serviceUrl+"ValidateAdminLogin",
      {
        "Username": data.Username,
        "Password": data.Password,     
      });
  }

  //Validate student data
  public  validatestudent(data:StudentLoginM ) {
    return this.https.post(this.serviceUrl+"ValidateUserLogin",
      {
        "Username": data.Username,
        "Password": data.Password,     
      });
  }

  
//Validate Admin data
public  saveApplication(a:ApplicationModel ) {
  return this.https.post(this.serviceUrl+"addApplication",
    {
      "ApplicationID":a.ApplicationID	,	
      "Course":a.Course,
      "Fname":a.Fname,
      "Lname":a.Lname,
      "Fullname":a.Fullname,
      "DOB":a.DOB	,
      "Gender":a.Gender,
      "FatherName":a.FatherName	,
      "MotherName":a.MotherName	,
      "Religion":a.Religion,
      "Nationality":a.Nationality	,
      "Email":a.Email,
      "MobileNo":a.MobileNo,
      "P_Address":a.P_Address	,
      "C_Address":a.C_Address	,     
      "SSLCSchoolName":a.SSLCSchoolName,
      "SSLCMark":a.SSLCMark,
      "SSLCPercentage":a.SSLCPercentage,
      "HSCSchoolName":a.HSCSchoolName,
      "HSCMark":a.HSCMark,
      "HSCPercentage":a.HSCPercentage,
      "UGSchoolName":a.UGSchoolName	,
      "UGMark":a.UGMark,
      "UGPercentage":a.UGPercentage	,
      "PGSchoolName":a.PGSchoolName	,
      "PGMark":a.PGMark,
      "PGPercentage":a.PGPercentage	,
      "CreateOn":a.CreateOn,
      "isActive":a.isActive
    });
}

}