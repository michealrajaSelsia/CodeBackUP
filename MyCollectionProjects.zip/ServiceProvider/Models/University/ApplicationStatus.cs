﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceProvider.Models.University
{
    public class ApplicationStatus
    {
        public string ApplicationID { get; set; }
        public string ApprovedStatus { get; set; }
        public string ApprovedBy { get; set; }
        public string ApplicationComment { get; set; }
        public DateTime ApprovedOn { get; set; }
    }
}